bs(rq[i] - initial);
        initial = rq[i