#include <stdio.h>
int main()
{
    int i, j, n, p, r, alloc[10][10], need[10][10], max[10][10], finish[10], work[10], available[10];

    printf("\nEnter how many processes you want: ");
    scanf("%d", &p);
    printf("\n Enter how many resources you want: ");
    scanf("%d", &r);

    // allocation matrix logic
    printf("Enter the allocation matric: ");
    for (i = 0; i < p; i++)
    {
        finish[i] = -1;
        printf("P%d\t", i);
        for (j = 0; j < r; j++)
            scanf("%d", &alloc[i][j]);
    }
    // max matrix logic
    printf("\n Enter the max demand matrix: ");
    for (i = 0; i < p; i++)
    {
        printf("P%d\t", i);
        for (j = 0; j < r; j++)
            scanf("%d", &max[i][j]);
    }

    // available matrix logic
    printf("\n Enter the available resource matrix: ");
    for (i = 0; i < r; i++)
    {
        scanf("%d", &available[i]);
    }

    // displaying allocation matrix
    printf("\n The contents of allocation matrix is: ");
    for (i = 0; i < p; i++)
    {
        printf("\nP%d", i);
        for (j = 0; j < r; j++)
            printf("\t%d", alloc[i][j]);
    }

    // displaying max matrix
    printf("\n The contents of max  demand matrix is: ");
    for (i = 0; i < p; i++)
    {
        printf("\n P%d", i);
        for (j = 0; j < r; j++)
            printf("\t%d", max[i][j]);
    }

    // displaying need matrix
    printf("\n The contents of need array is: ");
    for (i = 0; i < p; i++)
    {
        printf("\nP%d", i);
        for (j = 0; j < r; j++)
        {
            need[i][j] = max[i][j] - alloc[i][j];
            printf("\t%d", need[i][j]);
        }
    }
    printf("\n The contents of Available Matrix is:");
    for (i = 0; i < r; i++)
    {

        printf("\t%d", available[i]);
    }
}