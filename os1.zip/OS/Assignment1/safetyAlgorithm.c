#include <stdio.h>
int main()
{
    int i, j, m, n, p, r, no, k = 0, flag = 0, flag1 = 0, flag2 = 0, request[10], safe[10], alloc[10][10], need[10][10], max[10][10], finish[10], work[10], available[10];
    //   clrscr();
    printf("\n Enter the how many process you want:");
    scanf("%d", &p);
    printf(" Enter the how many resources you want:");
    scanf("%d", &r);
    printf("\n Enter the allocation matrix:\n");
    for (i = 0; i < p; i++)
    {
        finish[i] = -1;
        printf(" P%d\t", i);
        for (j = 0; j < r; j++)
            scanf("%d", &alloc[i][j]);
    }
    printf("\n Enter the maximum demand of matrix:\n");
    for (i = 0; i < p; i++)
    {
        printf(" P%d\t", i);
        for (j = 0; j < r; j++)
            scanf("%d", &max[i][j]);
    }
    printf("\n Enter the available resource matrix: ");
    for (i = 0; i < r; i++)
    {
        scanf("%d", &available[i]);
        work[i] = available[i];
    }
    printf("\n The contents of need array is:");
    for (i = 0; i < p; i++)
    {
        printf("\n P%d", i);
        for (j = 0; j < r; j++)
        {
            need[i][j] = max[i][j] - alloc[i][j];
            printf("\t%d", need[i][j]);
        }
    }
loop:
    for (i = 0; i < p; i++)
    {
        // it will check for process where it is granted or not, if not granted it will be false i.e. finish = -1 else it will be true
        if (finish[i] == -1)
        {
            j = m = 0;
            while (j < r)
            {
                // need(p1) <= work
                if (need[i][j] <= work[j])
                    j++;
                else
                {
                    printf("\n P%d has to wait, it is not safe", i);

                    m = -1; // false
                    break;
                }
            }
            if (m != -1)
            {
                for (n = 0; n < r; n++)
                    work[n] = work[n] + alloc[i][n];
                finish[i] = 0; // finish = true
                printf("\n P%d is safe", i);
                safe[k] = i;
                k++;
                printf("\n Safe sequence is: ");
                for (n = 0; n < k; n++)
                    printf("  P%d", safe[n]);
            }
        }
    }
    for (n = 0; n < p; n++)
    {
        if (finish[n] == -1)
            goto loop;
        else if (flag == 1)
            goto end;
    }

end:
    for (i = 0; i < p; i++)
    {
        if (finish[i] == -1)
            goto loop;
        else if (i == p - 1)
        {
            printf("\n Yes, System is in safe state. ");
            break;
        }
    }
}