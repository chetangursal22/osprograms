#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

void allocate(int a, int n)
{
    int i;
    for (i = 0; i < n; i++)
    {
        a[i] = rand() % 50;
    }
}
void main(int argc, char *argv[])
{
    int i, n, size, rank, avg, sum = 0, count;
    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    n = atoi(argv[1]);
    count = n / size;

    if (rank == 0)
    {
        a = (int *)malloc(sizeof(int));
        allocate(a, n);
    }

    for (i = 0; i < count; i++)
    {
        printf("\n%d\t", a[i]);
        sum = sum + a[i];
    }
    avg = sum / count;
    printf("Average of 10 integers is %d", avg);
    MPI_FINALIZE();
}
